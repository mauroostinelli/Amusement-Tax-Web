// app/page.tsx
"use client";

import { useEffect, useState } from "react";
import {
  db,
  collection,
  query,
  where,
  getDocs,
  orderBy,
  limit,
} from "../lib/firebase";
import Link from "next/link";

type CityEntry = {
  id: string;
  city: string;
  country: string;
  taxName?: string;
  amountPerNight: number;
  currency: string;
  collector: string;
  lawUrl?: string;
  votes: number;
};

export default function HomePage() {
  const [search, setSearch] = useState("");
  const [result, setResult] = useState<CityEntry | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (!search.trim()) return;
    setLoading(true);
    try {
      const q = query(
        collection(db, "cities"),
        where("city_lower", "==", search.trim().toLowerCase()),
        orderBy("votes", "desc"),
        limit(1)
      );
      const snap = await getDocs(q);
      if (!snap.empty) {
        const doc = snap.docs[0];
        setResult({ id: doc.id, ...(doc.data() as any) });
      } else {
        setResult(null);
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <section className="flex flex-col items-center text-center gap-6 mb-16">
        <div className="inline-flex items-center justify-center rounded-full border border-cyan-400/40 bg-cyan-500/10 px-4 py-1 text-xs font-semibold text-cyan-300">
          🎢 AMUSEMENT TAX
        </div>
        <h1 className="text-4xl md:text-5xl font-semibold tracking-tight text-slate-50">
          La ciudad como <span className="text-cyan-300">parque de atracciones</span>.
        </h1>
        <p className="max-w-3xl text-slate-300 text-sm md:text-base">
          Cada vez más ciudades cobran tasas turísticas por dormir en ellas.
          Si pagas por entrar y pernoctar dentro de unos límites urbanos,
          ¿sigues siendo visitante o ya eres cliente con derecho a reclamar?
        </p>
        <p className="max-w-2xl text-slate-400 text-xs md:text-sm">
          Este proyecto recopila, de forma colaborativa, las tasas turísticas del mundo
          y genera reclamaciones automáticas cuando la experiencia urbana no está a la altura
          del precio de entrada.
        </p>
      </section>

      <section className="max-w-xl mx-auto mb-16">
        <form
          onSubmit={handleSearch}
          className="flex flex-col gap-3 items-stretch"
        >
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Busca una ciudad (Barcelona, Madrid, Sevilla, Bilbao, Málaga...)"
            className="w-full rounded-md border border-slate-700 bg-slate-900 px-4 py-3 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-cyan-400/70"
          />
          <button
            type="submit"
            className="inline-flex justify-center rounded-md bg-cyan-500 px-4 py-2 text-sm font-semibold text-slate-950 hover:bg-cyan-400 focus:outline-none focus:ring-2 focus:ring-cyan-400/70"
          >
            {loading ? "Buscando..." : "Buscar tasa turística"}
          </button>
        </form>

        {search && !loading && !result && (
          <p className="mt-4 text-sm text-slate-400">
            No tenemos aún datos para esa ciudad. Puedes añadirla desde la pestaña{" "}
            <Link href="/cities" className="text-cyan-400 underline">
              Ciudades
            </Link>.
          </p>
        )}

        {result && (
          <div className="mt-8 rounded-lg border border-slate-800 bg-slate-900/60 p-4 text-left">
            <h2 className="text-lg font-semibold text-slate-50">
              {result.city}, {result.country}
            </h2>
            {result.taxName && (
              <p className="text-sm text-slate-300 mt-1">
                {result.taxName}
              </p>
            )}
            <p className="mt-3 text-sm text-slate-200">
              Importe:{" "}
              <span className="font-semibold text-cyan-300">
                {result.amountPerNight.toFixed(2)} {result.currency}
              </span>{" "}
              por noche y persona.
            </p>
            <p className="mt-1 text-xs text-slate-400">
              Recauda: {result.collector}
            </p>
            {result.lawUrl && (
              <a
                href={result.lawUrl}
                target="_blank"
                className="mt-2 inline-block text-xs text-cyan-300 underline"
              >
                Ver normativa
              </a>
            )}
            <p className="mt-2 text-xs text-slate-500">
              Entrada mejor valorada por la comunidad ({result.votes} votos).
            </p>
          </div>
        )}
      </section>

      <section className="mt-16 text-center">
        <p className="text-xs text-slate-500">
          Datos iniciales cargados para Barcelona, Madrid, Sevilla, Bilbao y Málaga.
          Puedes explorar todas en{" "}
          <Link href="/cities" className="text-cyan-400 underline">
            Ciudades
          </Link>{" "}
          o generar tu reclamación en{" "}
          <Link href="/claim" className="text-cyan-400 underline">
            Reclama
          </Link>.
        </p>
      </section>
    </div>
  );
}