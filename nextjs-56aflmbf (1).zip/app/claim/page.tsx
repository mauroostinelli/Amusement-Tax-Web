// app/claim/page.tsx
"use client";

import { useState } from "react";

export default function ClaimPage() {
  const [form, setForm] = useState({
    name: "",
    days: "",
    city: "",
    hotel: "",
    reason: "",
    language: "es",
    otherLang: "",
  });
  const [loading, setLoading] = useState(false);
  const [text, setText] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setText("");
    const language =
      form.language === "other" ? form.otherLang || "es" : form.language;

    try {
      const res = await fetch("/api/gemini", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name,
          days: form.days,
          city: form.city,
          hotel: form.hotel,
          reason: form.reason,
          language,
        }),
      });
      const data = await res.json();
      setText(data.text || "Error generando el texto.");
    } catch (e) {
      setText("Error llamando a la API.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-semibold text-slate-50 mb-2">
        Reclama tu tasa turística
      </h1>
      <p className="text-xs text-slate-400 mb-6 max-w-2xl">
        Rellena este formulario y generaremos un escrito formal de reclamación
        solicitando la devolución de lo pagado por la tasa turística más un
        50% adicional en concepto de compensaciones y gastos de gestión.
      </p>

      <form
        onSubmit={handleSubmit}
        className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm mb-8 rounded-lg border border-slate-800 bg-slate-900/70 p-4"
      >
        <div className="md:col-span-2">
          <label className="block text-xs text-slate-400 mb-1">
            Nombre y apellidos
          </label>
          <input
            className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            required
          />
        </div>
        <div>
          <label className="block text-xs text-slate-400 mb-1">
            Ciudad
          </label>
          <input
            className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
            value={form.city}
            onChange={(e) => setForm({ ...form, city: e.target.value })}
            required
          />
        </div>
        <div>
          <label className="block text-xs text-slate-400 mb-1">
            Días de estancia
          </label>
          <input
            type="number"
            min={1}
            className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
            value={form.days}
            onChange={(e) => setForm({ ...form, days: e.target.value })}
            required
          />
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs text-slate-400 mb-1">
            Nombre del hotel o alojamiento
          </label>
          <input
            className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
            value={form.hotel}
            onChange={(e) => setForm({ ...form, hotel: e.target.value })}
            required
          />
        </div>
        <div className="md:col-span-2">
          <label className="block text-xs text-slate-400 mb-1">
            Motivo de la reclamación (sé lo más detallado posible)
          </label>
          <textarea
            className="w-full min-h-[120px] rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
            value={form.reason}
            onChange={(e) => setForm({ ...form, reason: e.target.value })}
            required
          />
        </div>

        <div>
          <label className="block text-xs text-slate-400 mb-1">
            Idioma del recurso
          </label>
          <select
            className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
            value={form.language}
            onChange={(e) =>
              setForm({ ...form, language: e.target.value })
            }
          >
            <option value="es">Español (nativo)</option>
            <option value="en">Inglés (nativo)</option>
            <option value="other">Otro (via Google Translate)</option>
          </select>
        </div>

        {form.language === "other" && (
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Especifica idioma (ej. "francés", "alemán")
            </label>
            <input
              className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
              value={form.otherLang}
              onChange={(e) =>
                setForm({ ...form, otherLang: e.target.value })
              }
              required
            />
          </div>
        )}

        <div className="md:col-span-2 flex justify-end pt-2">
          <button
            type="submit"
            className="rounded-md bg-cyan-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-cyan-400"
          >
            {loading ? "Generando..." : "Generar reclamación"}
          </button>
        </div>
      </form>

      {text && (
        <section className="rounded-lg border border-slate-800 bg-slate-900/70 p-4 text-sm whitespace-pre-wrap">
          <h2 className="text-sm font-semibold text-slate-50 mb-2">
            Recurso generado
          </h2>
          <p className="text-slate-200">{text}</p>
        </section>
      )}
    </div>
  );
}
