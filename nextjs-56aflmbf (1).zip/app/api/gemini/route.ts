// app/api/gemini/route.ts
import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextResponse } from "next/server";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);

export async function POST(req: Request) {
  const { name, days, city, hotel, reason, language } = await req.json();

  const promptES = `
Eres un experto abogado en derecho del consumidor y reclamaciones administrativas. 
Genera un recurso formal, completo, muy elaborado y jurídicamente fundamentado para reclamar la devolución de una tasa turística. El recurso debe:

1. Tener estructura completa: encabezado, fundamentos de derecho, hechos, petición.
2. Citar normativas aplicables reales o genéricas de consumo, contratos de adhesión, protección de datos y turismo.
3. Solicitar la devolución íntegra de la tasa pagada MÁS un 50% adicional en concepto de compensación por perjuicios, gastos de gestión y mala experiencia urbana.
4. Usar tono muy formal y técnico-jurídico, con lenguaje especializado.
5. Extensión mínima: 600 palabras.

Datos del reclamante:
- Nombre: ${name}
- Ciudad visitada: ${city}
- Alojamiento: ${hotel}
- Días de estancia: ${days}
- Motivo de reclamación: ${reason}

Genera el recurso completo, listo para presentar ante el organismo competente.
`;

  const promptEN = `
You are an expert lawyer in consumer law and administrative claims.
Generate a complete, formal, highly detailed and legally grounded appeal to request a refund of a tourist tax. The document must:

1. Have full structure: heading, legal grounds, facts, petition.
2. Cite real or generic applicable regulations on consumer law, adhesion contracts, data protection, and tourism.
3. Request the full refund of the tax paid PLUS an additional 50% as compensation for damages, management costs, and poor urban experience.
4. Use very formal, technical-legal language with specialized terminology.
5. Minimum length: 600 words.

Claimant information:
- Name: ${name}
- City visited: ${city}
- Accommodation: ${hotel}
- Days of stay: ${days}
- Reason for claim: ${reason}

Generate the complete appeal, ready to be submitted to the competent authority.
`;

  const isSpanish = language === "es";
  const finalPrompt = isSpanish ? promptES : promptEN;

  try {
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });
    const result = await model.generateContent(finalPrompt);
    const response = await result.response;
    let text = response.text();

    // Si es otro idioma, usar prompt de traducción adicional
    if (!isSpanish && language !== "en") {
      const translatePrompt = `Translate the following legal appeal to ${language} language, maintaining the formal legal tone:\n\n${text}`;
      const translateResult = await model.generateContent(translatePrompt);
      const translateResponse = await translateResult.response;
      text = translateResponse.text();
    }

    return NextResponse.json({ text });
  } catch (error: any) {
    console.error("Gemini API error:", error);
    return NextResponse.json(
      { error: error.message || "Unknown error" },
      { status: 500 }
    );
  }
}
