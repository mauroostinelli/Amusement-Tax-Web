// app/layout.tsx
import "./globals.css";
import Link from "next/link";

export const metadata = {
  title: "Amusement Tax",
  description:
    "Mapa colaborativo de tasas turísticas y generador de reclamaciones automáticas.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body className="bg-slate-950 text-slate-100">
        <header className="w-full border-b border-slate-800 bg-slate-900/80 backdrop-blur">
          <div className="max-w-5xl mx-auto flex items-center justify-between py-4 px-4">
            <Link href="/" className="flex items-center gap-2">
              <span className="inline-flex items-center justify-center rounded-md bg-cyan-500/10 border border-cyan-400/40 px-2 py-1 text-xs font-semibold text-cyan-300">
                🎢
              </span>
              <span className="font-semibold tracking-tight">
                Amusement Tax
              </span>
            </Link>
            <nav className="flex items-center gap-4 text-sm text-slate-300">
              <Link href="/" className="hover:text-cyan-300">
                Inicio
              </Link>
              <Link href="/cities" className="hover:text-cyan-300">
                Ciudades
              </Link>
              <Link href="/claim" className="hover:text-cyan-300">
                Reclama
              </Link>
            </nav>
          </div>
        </header>
        <main className="min-h-screen bg-slate-950">
          {children}
        </main>
      </body>
    </html>
  );
}