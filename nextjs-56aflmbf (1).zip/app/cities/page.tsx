// app/cities/page.tsx
"use client";

import { useEffect, useState } from "react";
import {
  db,
  collection,
  getDocs,
  query,
  orderBy,
  addDoc,
  ensureAnonymousUser,
  doc,
  updateDoc,
  increment,
} from "../../lib/firebase";

type CityEntry = {
  id: string;
  city: string;
  country: string;
  taxName?: string;
  amountPerNight: number;
  currency: string;
  collector: string;
  lawUrl?: string;
  votes: number;
};

export default function CitiesPage() {
  const [cities, setCities] = useState<CityEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState({
    city: "",
    country: "",
    taxName: "",
    amountPerNight: "",
    currency: "€",
    collector: "",
    lawUrl: "",
  });

  async function loadCities() {
    setLoading(true);
    const q = query(collection(db, "cities"), orderBy("votes", "desc"));
    const snap = await getDocs(q);
    const list: CityEntry[] = snap.docs.map((d) => ({
      id: d.id,
      ...(d.data() as any),
    }));
    setCities(list);
    setLoading(false);
  }

  useEffect(() => {
    loadCities();
  }, []);

  async function handleVote(id: string, delta: 1 | -1) {
    await ensureAnonymousUser();
    const ref = doc(db, "cities", id);
    await updateDoc(ref, {
      votes: increment(delta),
    });
    await loadCities();
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const userId = await ensureAnonymousUser();
    await addDoc(collection(db, "cities"), {
      city: form.city.trim(),
      city_lower: form.city.trim().toLowerCase(),
      country: form.country.trim() || "Desconocido",
      taxName: form.taxName.trim() || null,
      amountPerNight: parseFloat(form.amountPerNight),
      currency: form.currency,
      collector: form.collector.trim(),
      lawUrl: form.lawUrl.trim() || null,
      votes: 0,
      userId,
      createdAt: new Date().toISOString(),
    });
    setForm({
      city: "",
      country: "",
      taxName: "",
      amountPerNight: "",
      currency: "€",
      collector: "",
      lawUrl: "",
    });
    setFormOpen(false);
    await loadCities();
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-slate-50">
            Ciudades con tasa turística
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Base de datos colaborativa. Cada entrada representa una combinación
            ciudad + tipo de alojamiento / criterio principal. La entrada más
            votada es la que se muestra en el buscador.
          </p>
        </div>
        <button
          onClick={() => setFormOpen((v) => !v)}
          className="rounded-md bg-cyan-500 px-3 py-2 text-xs font-semibold text-slate-950 hover:bg-cyan-400"
        >
          {formOpen ? "Cerrar" : "Añadir ciudad"}
        </button>
      </div>

      {formOpen && (
        <form
          onSubmit={handleSubmit}
          className="mb-8 rounded-lg border border-slate-800 bg-slate-900/70 p-4 grid grid-cols-1 md:grid-cols-2 gap-3 text-sm"
        >
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Ciudad
            </label>
            <input
              className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
              value={form.city}
              onChange={(e) => setForm({ ...form, city: e.target.value })}
              required
            />
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              País
            </label>
            <input
              className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
              value={form.country}
              onChange={(e) => setForm({ ...form, country: e.target.value })}
              placeholder="España, Italia..."
            />
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Nombre oficial de la tasa
            </label>
            <input
              className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
              value={form.taxName}
              onChange={(e) => setForm({ ...form, taxName: e.target.value })}
              placeholder="Impuesto sobre las Estancias..."
            />
          </div>
          <div className="flex gap-2">
            <div className="flex-1">
              <label className="block text-xs text-slate-400 mb-1">
                Importe por noche (persona)
              </label>
              <input
                type="number"
                step="0.01"
                className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
                value={form.amountPerNight}
                onChange={(e) =>
                  setForm({ ...form, amountPerNight: e.target.value })
                }
                required
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">
                Moneda
              </label>
              <input
                className="w-16 rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
                value={form.currency}
                onChange={(e) =>
                  setForm({ ...form, currency: e.target.value })
                }
              />
            </div>
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Organismo recaudador
            </label>
            <input
              className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
              value={form.collector}
              onChange={(e) =>
                setForm({ ...form, collector: e.target.value })
              }
              placeholder="Agència Tributària de Catalunya"
              required
            />
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              Enlace a la norma (opcional)
            </label>
            <input
              className="w-full rounded-md border border-slate-700 bg-slate-950 px-3 py-2 text-xs"
              value={form.lawUrl}
              onChange={(e) => setForm({ ...form, lawUrl: e.target.value })}
              placeholder="https://..."
            />
          </div>
          <div className="md:col-span-2 flex justify-end pt-2">
            <button
              type="submit"
              className="rounded-md bg-cyan-500 px-3 py-2 text-xs font-semibold text-slate-950 hover:bg-cyan-400"
            >
              Guardar ciudad
            </button>
          </div>
        </form>
      )}

      {loading ? (
        <p className="text-sm text-slate-400">Cargando ciudades...</p>
      ) : (
        <div className="space-y-3">
          {cities.map((c) => (
            <div
              key={c.id}
              className="flex flex-col md:flex-row md:items-center justify-between gap-2 rounded-md border border-slate-800 bg-slate-900/70 p-3 text-sm"
            >
              <div>
                <p className="font-semibold text-slate-50">
                  {c.city}, {c.country}
                </p>
                {c.taxName && (
                  <p className="text-xs text-slate-300 mt-1">{c.taxName}</p>
                )}
                <p className="text-xs text-slate-300 mt-1">
                  {c.amountPerNight.toFixed(2)} {c.currency} por noche y
                  persona · Recauda: {c.collector}
                </p>
                {c.lawUrl && (
                  <a
                    href={c.lawUrl}
                    target="_blank"
                    className="text-xs text-cyan-300 underline mt-1 inline-block"
                  >
                    Ver normativa
                  </a>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleVote(c.id, 1)}
                  className="rounded-full bg-slate-800 text-cyan-300 px-2 py-1 text-xs hover:bg-slate-700"
                >
                  ▲
                </button>
                <span className="text-xs text-slate-300 min-w-[40px] text-center">
                  {c.votes} votos
                </span>
                <button
                  onClick={() => handleVote(c.id, -1)}
                  className="rounded-full bg-slate-800 text-pink-300 px-2 py-1 text-xs hover:bg-slate-700"
                >
                  ▼
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
